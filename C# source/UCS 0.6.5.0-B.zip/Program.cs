﻿using UCS.Core.Threading;

namespace UCS
{
    class Program
    {
        static void Main()
        {
            ConsoleThread.Start();
        }
    }
}