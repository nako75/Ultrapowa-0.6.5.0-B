﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UCS.PacketProcessing
{
    class AllianceFullEntryUpdateMessage : Message
    {
        public static int PacketID = 24324;
    }
}
