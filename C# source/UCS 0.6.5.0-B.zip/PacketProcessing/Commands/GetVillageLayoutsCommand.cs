﻿using System.IO;

namespace UCS.PacketProcessing
{
    internal class GetVillageLayoutsCommand : Command
    {
        public GetVillageLayoutsCommand(BinaryReader br) { }
    }
}