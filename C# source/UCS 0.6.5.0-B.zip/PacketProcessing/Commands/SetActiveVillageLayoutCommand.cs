﻿using System.IO;

namespace UCS.PacketProcessing
{
    internal class SetActiveVillageLayoutCommand : Command
    {
        public SetActiveVillageLayoutCommand(BinaryReader br) { }
    }
}