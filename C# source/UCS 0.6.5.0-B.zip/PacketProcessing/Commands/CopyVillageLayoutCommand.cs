﻿using System.IO;

namespace UCS.PacketProcessing
{
    internal class CopyVillageLayoutCommand : Command
    {
        public CopyVillageLayoutCommand(BinaryReader br) { }
    }
}